# coding: utf-8
from __future__ import unicode_literals


WORKSPACE_ROOT = "/default-domain/workspaces"
WORKSPACE_NAME = "ws-python-tests"
WORKSPACE_TEST = WORKSPACE_ROOT + "/" + WORKSPACE_NAME
