#
# The content of this file will be filled in with meaningful data
# when creating an archive using `git archive` or by downloading an
# archive from github, e.g. from github.com/.../archive/develop.zip
#
rev = "41237b1035"     # abbreviated commit hash
commit = "41237b1035ff71abba007410b51e4da8b49919e1"  # commit hash
date = "2019-11-08 17:34:46 +0100"   # commit date
author = "Jonathan Springer <springermac@gmail.com>"
ref_names = ""  # incl. current branch
commit_message = """modulegraph: Fix not matching filetypes ending in cpython-37m.dll.

Fixes: #4125. MINGW Python packages in MSYS2 name Windows dll files with
a -cpython-37m.dll extension. Loading a Python module that depends on a
dll, for example struct and zlib, results in a ModuleNotFoundError since
modulegraph is not looking for files with this naming convention.

Co-authored-by: Jonathan Springer <springermac@gmail.com>
Co-authored-by: Dan Yeaw <dan@yeaw.me>
"""
