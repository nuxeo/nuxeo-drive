#
# The content of this file will be filled in with meaningful data
# when creating an archive using `git archive` or by downloading an
# archive from github, e.g. from github.com/.../archive/develop.zip
#
rev = "3f57c91422"     # abbreviated commit hash
commit = "3f57c91422c1e48d284fa66d09f6aa3e3c6dbf9c"  # commit hash
date = "2019-10-04 16:45:59 -0500"   # commit date
author = "Bryan A. Jones <bjones@ece.msstate.edu>"
ref_names = ""  # incl. current branch
commit_message = """Test/CI: Include QTranslate tests for PySide2.
"""
